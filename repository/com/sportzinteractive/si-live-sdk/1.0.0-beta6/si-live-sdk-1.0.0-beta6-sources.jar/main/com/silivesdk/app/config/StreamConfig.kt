package com.silivesdk.app.config

import com.silivesdk.app.model.MediaType

/**
 * Configuration for a specific locales in a stream configuration.
 */
data class localesConfig(
    val mediaType: MediaType,
    val mediaUrl: String = "",
    val mediaTitle: String = "",
    val mediaSubTitle: String = "",
    val mediaLoop: Boolean = true
)

/**
 * Configuration for a specific environment (prod/non-prod) in a stream configuration.
 */
data class EnvironmentConfig(
    val liveVideoId: String? = null, // New field name
    val videoId: String? = null, // Legacy field name (for backward compatibility)
    val liveVideoOrientation: String? = null, // "portrait" or "landscape"
    val liveMediaTitle: String? = null, // Title for live state overlay
    val liveMediaSubTitle: String? = null, // Subtitle for live state overlay
    val state: String? = null, // "preLive", "live", "postLive"
    val locales: Map<String, localesConfig>? = null,
    val intervals: Map<String, Int>? = null // polling intervals in seconds: "preLive", "live", "postLive"
)

/**
 * Configuration for a specific event type (camera/mobile).
 */
data class EventTypeConfig(
    val prod: EnvironmentConfig,
    val nonProd: EnvironmentConfig? = null
)

/**
 * Root configuration object that holds all stream configurations.
 */
data class StreamConfiguration(
    val camera: EventTypeConfig,
    val mobile: EventTypeConfig
)
