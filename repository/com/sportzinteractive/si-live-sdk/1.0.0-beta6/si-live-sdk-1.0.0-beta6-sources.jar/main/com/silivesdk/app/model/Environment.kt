package com.silivesdk.app.model

/**
 * Deployment environment provided by the host app.
 */
enum class Environment {
    prod,
    nonProd
}


