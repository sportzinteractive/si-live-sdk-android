package com.silivesdk.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * Custom image loading composable that replaces Coil's AsyncImage.
 * Uses Android's built-in BitmapFactory - no external dependencies required.
 */
@Composable
fun AsyncImage(
    model: String,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Fit,
    crossfade: Boolean = false
) {
    val context = LocalContext.current
    var bitmap by remember(model) { mutableStateOf<Bitmap?>(null) }
    var isLoading by remember(model) { mutableStateOf(true) }
    var errorMessage by remember(model) { mutableStateOf<String?>(null) }

    LaunchedEffect(model) {
        if (model.isNotEmpty()) {
            Logger.d("AsyncImage: Starting to load image from URL: $model")
            isLoading = true
            errorMessage = null
            bitmap = withContext(Dispatchers.IO) {
                try {
                    val loadedBitmap = loadBitmapFromUrl(model)
                    if (loadedBitmap == null) {
                        Logger.e("AsyncImage: Failed to load image from URL: $model - bitmap is null")
                        errorMessage = "Failed to load image"
                    } else {
                        Logger.d("AsyncImage: Successfully loaded image from URL: $model (size: ${loadedBitmap.width}x${loadedBitmap.height})")
                    }
                    loadedBitmap
                } catch (e: Exception) {
                    Logger.e("AsyncImage: Exception while loading image from URL: $model", e)
                    errorMessage = e.message ?: "Unknown error"
                    null
                } finally {
                    isLoading = false
                }
            }
        } else {
            Logger.w("AsyncImage: Empty URL provided, cannot load image")
            bitmap = null
            isLoading = false
            errorMessage = "Empty URL"
        }
    }

    bitmap?.let {
        Image(
            bitmap = it.asImageBitmap(),
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = contentScale
        )
    } ?: run {
        // Log when image is not displayed
        if (errorMessage != null) {
            Logger.e("AsyncImage: Not displaying image - $errorMessage (URL: $model)")
        } else if (isLoading) {
            Logger.d("AsyncImage: Still loading image from URL: $model")
        } else {
            Logger.w("AsyncImage: Image bitmap is null for URL: $model")
        }
    }
}

/**
 * Loads a bitmap from a URL using Android's built-in classes.
 */
private suspend fun loadBitmapFromUrl(urlString: String): Bitmap? {
    return withContext(Dispatchers.IO) {
        try {
            Logger.d("loadBitmapFromUrl: Attempting to load image from: $urlString")
            val url = URL(urlString)
            val connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = 10000
            connection.readTimeout = 10000
            connection.doInput = true
            connection.connect()

            val responseCode = connection.responseCode
            Logger.d("loadBitmapFromUrl: HTTP response code: $responseCode for URL: $urlString")
            
            if (responseCode != HttpURLConnection.HTTP_OK) {
                Logger.e("loadBitmapFromUrl: HTTP error code $responseCode for URL: $urlString")
                connection.disconnect()
                return@withContext null
            }

            val inputStream = connection.inputStream
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream.close()
            connection.disconnect()

            if (bitmap == null) {
                Logger.e("loadBitmapFromUrl: BitmapFactory.decodeStream returned null for URL: $urlString")
            } else {
                Logger.d("loadBitmapFromUrl: Successfully decoded bitmap (${bitmap.width}x${bitmap.height}) from URL: $urlString")
            }

            bitmap
        } catch (e: Exception) {
            Logger.e("loadBitmapFromUrl: Exception loading image from URL: $urlString", e)
            null
        }
    }
}

/**
 * Loads an image and returns it as a BitmapDrawable.
 * Used for extracting dominant colors.
 */
suspend fun loadImageAsDrawable(context: android.content.Context, imageUrl: String): BitmapDrawable? {
    return withContext(Dispatchers.IO) {
        try {
            val bitmap = loadBitmapFromUrl(imageUrl)
            bitmap?.let {
                BitmapDrawable(context.resources, it)
            }
        } catch (e: Exception) {
            Logger.e("loadImageAsDrawable: Exception loading image as drawable from URL: $imageUrl", e)
            null
        }
    }
}
