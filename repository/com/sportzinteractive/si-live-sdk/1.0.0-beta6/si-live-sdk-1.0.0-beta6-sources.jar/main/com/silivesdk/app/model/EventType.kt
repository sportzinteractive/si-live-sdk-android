package com.silivesdk.app.model

/**
 * Event type provided by the host app.
 */
enum class EventType {
    mobile,
    camera
}


