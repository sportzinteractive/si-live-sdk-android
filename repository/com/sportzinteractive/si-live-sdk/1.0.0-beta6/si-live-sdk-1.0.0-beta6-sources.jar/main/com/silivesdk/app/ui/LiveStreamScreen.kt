package com.silivesdk.app.ui

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
// Removed Coil - using custom AsyncImage instead
import androidx.lifecycle.viewmodel.compose.viewModel
import com.silivesdk.app.BrightcoveLiveStreamSDK
import com.silivesdk.app.ConfigurationChangeListener
import com.silivesdk.app.config.StreamConfigData
import com.silivesdk.app.viewmodel.LiveStreamViewModelFactory
import com.silivesdk.app.model.EventType
import com.silivesdk.app.model.Environment
import com.silivesdk.app.BuildConfig
import com.silivesdk.app.model.LiveStreamState
import com.silivesdk.app.model.MediaType
import com.silivesdk.app.model.PlayerEvent
import com.silivesdk.app.model.SDKError
import com.silivesdk.app.player.BrightcovePlayerView
import com.silivesdk.app.viewmodel.LiveStreamViewModel
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.StrokeCap
import com.silivesdk.app.R

/**
 * Main public UI entry point for the Live Streaming SDK.
 *
 * This is the single composable that parent apps should use to display live streaming.
 *
 * @param onClose Optional callback when user taps close/back button
 * @param onBackButtonClick Optional callback when user taps back button. Emits true/false boolean event.
 * @param onStateChanged Optional callback when the stream state changes
 * @param onError Optional callback when an error occurs
 * @param onPlayerEvent Optional callback for player events (playback, buffering, etc.)
 * @param preLiveImageUrl URL for the preview image shown before stream starts
 * @param preLiveScheduledTime Date/time when the live stream is scheduled to start
 * @param eventType Required event type (MOBILE/CAMERA)
 * @param environment Required environment (PROD/NON_PROD)
 * @param locales Required locales identifier (e.g., "en", "hi", "it") for configuration
 * @param state Configuration behavior toggle: true = existing behavior, false = config-driven behavior
 * @param accountId Optional override for Brightcove Account ID
 * @param policyKey Optional override for Brightcove Policy Key
 * @param videoId Optional Brightcove Video ID for the stream
 * @param liveTitle Title shown during live stream
 * @param liveDescription Description shown during live stream
 * @param showCloseButton Whether to show the close/back button (default: true)
 * @param showPlayerControls Whether to show native Brightcove player controls (default: true)
 * @param errorRetryText Custom text for retry button in error state (default: "Retry")
 * @param loadingText Custom text for loading indicator (default: "Loading...")
 * @param debug Optional debug flag (default: BuildConfig.DEBUG)
 * @param modifier Modifier for the composable
 */
@Composable
fun LiveStreamScreen(
    eventType: EventType,
    environment: Environment,
    locales: String,
    onBackButtonClick: ((Boolean) -> Unit)? = null,
    modifier: Modifier,
    debug: Boolean = BuildConfig.DEBUG
) {
    val context = LocalContext.current
    val errorRetryText = "Retry"
    val showCloseButton = false
    val loadingText = "Loading..."
    val onClose: (() -> Unit)? = null
    val onStateChanged: ((LiveStreamState) -> Unit)? = null
    val onError: ((String, SDKError) -> Unit)? = null
    val onPlayerEvent: ((PlayerEvent) -> Unit)? = null
    val showPlayerControls: Boolean = false

    // Initialize logger with debug setting
    Logger.isDebugEnabled = debug



    // Ensure SDK is initialized before creating the ViewModel to avoid race conditions.
    if (!BrightcoveLiveStreamSDK.isInitialized()) {
        BrightcoveLiveStreamSDK.initialize(
            context = context,
            eventType = eventType,
            environment = environment,
            locales = locales,
            debug = debug
        )
    }
    
    val viewModel: LiveStreamViewModel = viewModel(
        factory = LiveStreamViewModelFactory(
            context.applicationContext as Application
        )
    )
    val streamState by viewModel.streamState.collectAsState()
    val showOverlay by viewModel.showOverlay.collectAsState()
    val playerEvent by viewModel.playerEvent.collectAsState()

    // Register for configuration changes
    DisposableEffect(Unit) {
        val configListener = object : ConfigurationChangeListener {
            override fun onConfigurationChanged(newConfig: StreamConfigData) {
                if (debug) {
                    Logger.d("LiveStreamScreen: Configuration changed - liveVideoId: ${newConfig.liveVideoId}, state: ${newConfig.state}")
                }

                // Update ViewModel with new configuration
                viewModel.updateConfiguration(newConfig)

                // The ViewModel will handle updating the stream state based on new configuration
                // The UI will automatically update through the streamState StateFlow
            }
        }

        BrightcoveLiveStreamSDK.addConfigurationChangeListener(configListener)

        onDispose {
            BrightcoveLiveStreamSDK.removeConfigurationChangeListener(configListener)
        }
    }
    
    // Track pageview analytics and notify parent app of state changes
    LaunchedEffect(streamState) {
        val currentState = streamState
        when (currentState) {
            is LiveStreamState.PreLive -> {
                BrightcoveLiveStreamSDK.getAnalyticsManager()?.trackPageView("pre_live_screen")
            }
            is LiveStreamState.Live -> {
                BrightcoveLiveStreamSDK.getAnalyticsManager()?.trackPageView("live_stream_screen")
            }
            is LiveStreamState.Error -> {
                BrightcoveLiveStreamSDK.getAnalyticsManager()?.trackPageView("error_screen")
                onError?.invoke(currentState.errorMessage, currentState.errorCode)
            }
            is LiveStreamState.Loading -> {
                // Loading state - no analytics needed
            }
        }
        // Notify parent app of state change (optional callback)
        onStateChanged?.invoke(currentState)
    }
    
    // Handle player events
    LaunchedEffect(playerEvent) {
        playerEvent?.let { event ->
            onPlayerEvent?.invoke(event)
        }
    }
    
    // Note: We don't need to create player view early anymore since we use standalone EventEmitter
    // for Catalog creation. The player view will be created when Live state is reached.
    
    val currentState = streamState
    when (currentState) {
        is LiveStreamState.Loading -> {
            LoadingContent(
                loadingText = loadingText,
                onBackButtonClick = onBackButtonClick,
                modifier = modifier
            )
        }
        is LiveStreamState.PreLive -> {
            PreLiveContent(
                mediaType = currentState.mediaType,
                mediaUrl = currentState.mediaUrl,
                mediaTitle = currentState.mediaTitle,
                mediaSubTitle = currentState.mediaSubTitle,
                mediaLoop = currentState.mediaLoop,
                onBackButtonClick = onBackButtonClick,
                modifier = modifier
            )
        }
        is LiveStreamState.Live -> {
            LiveStreamContent(
                viewModel = viewModel,
                title = currentState.title,
                description = currentState.description,
                showOverlay = showOverlay,
                showPlayerControls = showPlayerControls,
                onTap = { viewModel.toggleOverlay() },
                onClose = onClose,
                showCloseButton = showCloseButton,
                onBackButtonClick = onBackButtonClick,
                modifier = modifier
            )
        }
        is LiveStreamState.Error -> {
            ErrorContent(
                errorMessage = currentState.errorMessage,
                errorCode = currentState.errorCode,
                retryable = currentState.retryable,
                retryText = errorRetryText,
                onRetry = { viewModel.retry() },
                onBackButtonClick = onBackButtonClick,
                modifier = modifier
            )
        }
    }
}



@Composable
private fun PreLiveContent(
    mediaType: MediaType,
    mediaUrl: String,
    mediaTitle: String,
    mediaSubTitle: String,
    mediaLoop: Boolean,
    onBackButtonClick: ((Boolean) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val ferrariSansRegular = FontFamily(
        Font(R.font.ferrari_sans_regular, FontWeight.Normal)
    )
    val ferrariSansLight = FontFamily(
        Font(R.font.ferrari_sans_light, FontWeight.Normal)
    )
    // Track composable lifecycle
    LaunchedEffect(Unit) {
        Logger.d("PreLiveContent: Composable created/entered")
    }

    DisposableEffect(Unit) {
        onDispose {
            Logger.d("PreLiveContent: Composable disposed/exited")
        }
    }

    // Debug logging for media type changes
    if (BuildConfig.DEBUG) {
        Logger.d("PreLiveContent: Displaying mediaType=$mediaType, mediaUrl=$mediaUrl, mediaTitle=$mediaTitle, mediaSubTitle=$mediaSubTitle")
    }

    // Force recomposition when media type changes by using it as part of the key
    // This ensures proper cleanup of video resources when switching to image
    // Monitor media type changes for debugging and cleanup
    LaunchedEffect(mediaType) {
        Logger.d("PreLiveContent: Switching to mediaType=$mediaType, url=$mediaUrl")

        // Additional cleanup when switching away from video
        if (mediaType != MediaType.VIDEO) {
            Logger.d("PreLiveContent: Switched away from VIDEO to $mediaType")
        }
    }

    when (mediaType) {
        MediaType.IMAGE -> {
            // Debug: Show that we're displaying image
            if (BuildConfig.DEBUG) {
                Logger.d("PreLiveContent: Displaying IMAGE content")
                Logger.d("PreLiveContent: mediaUrl='$mediaUrl', isEmpty=${mediaUrl.isEmpty()}, isBlank=${mediaUrl.isBlank()}")
            }
            // Load Ferrari Sans font with fallback to default font
            // Load Ferrari Sans font
            // Note: Make sure ferrari_sans_regular.ttf is copied to app/src/main/res/font/ and project is synced


            // Extract dominant color from image
            val dominantColor = rememberDominantColor(mediaUrl)
            
            // Image display that fills the whole screen
            Box(
                modifier = modifier
                    .background(Color.Black)
                    .fillMaxSize()
            ) {
                // Image that fills the entire screen (using custom AsyncImage - no Coil dependency)
                if (mediaUrl.isNotEmpty()) {
                    AsyncImage(
                        model = mediaUrl,
                        contentDescription = "Live stream preview",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop, // Fill the entire screen
                        crossfade = true
                    )
                } else {
                    Logger.e("PreLiveContent: mediaUrl is empty, cannot display image")
                }
                
                // Back button - always visible at top-left
                BackButton(
                    onBackButtonClick = onBackButtonClick,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(top = 20.dp, start = 16.dp, end = 16.dp, bottom = 16.dp)
                )
                
                // Title and subtitle overlay at bottom start (left-aligned)
                if (mediaTitle.isNotBlank() || mediaSubTitle.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 32.dp),
                        contentAlignment = Alignment.BottomStart
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(horizontal = 16.dp)
                                .background(
                                    Color(0xFF17191C),
                                    shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                                )
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalAlignment = Alignment.Start
                        ) {
                            if (mediaTitle.isNotBlank() && mediaTitle.isNotEmpty()) {
                                Text(
                                    text = mediaTitle,
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        lineHeight = 20.sp
                                    ),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Start,
                                    fontFamily = ferrariSansRegular,
                                    fontSize = 18.sp
                                )
                            }
                            if (mediaSubTitle.isNotBlank() && mediaSubTitle.isNotEmpty()) {
                                if (mediaTitle.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                }
                                Text(
                                    text = mediaSubTitle,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        lineHeight = 18.sp
                                    ),
                                    color = Color.White.copy(alpha = 0.9f),
                                    textAlign = TextAlign.Start,
                                    fontFamily = ferrariSansLight,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        MediaType.VIDEO -> {
            // Debug: Show that we're displaying video
            if (BuildConfig.DEBUG) {
                Logger.d("PreLiveContent: Displaying VIDEO content - mediaUrl=$mediaUrl")
            }

            // Try to extract color from video thumbnail (if available) or use fallback
            // For video, we attempt to extract from thumbnail URL or use a default color
            val dominantColor = rememberDominantColor(mediaUrl)

            // Video display that fills the whole screen
            Box(
                modifier = modifier
                    .background(Color.Black)
                    .fillMaxSize()
            ) {
                // Video player that fills the screen - only active when mediaType is VIDEO
                if (mediaType == MediaType.VIDEO) {
                    val videoKey = "video_${mediaUrl}"
                    Logger.d("PreLiveContent: Creating VideoPlayer with key=$videoKey")
                    key(videoKey) {
                        VideoPlayer(
                            videoUrl = mediaUrl,
                            loop = mediaLoop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                // Back button - always visible at top-left
                BackButton(
                    onBackButtonClick = onBackButtonClick,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(top = 20.dp, start = 16.dp, end = 16.dp, bottom = 16.dp)
                )

                // Title and subtitle overlay at bottom start (left-aligned)
                if (mediaTitle.isNotBlank() || mediaSubTitle.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(all = 10.dp),
                        contentAlignment = Alignment.BottomStart
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(horizontal = 16.dp)
                                .background(
                                    Color(0xFF17191C),
                                    shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                                )
                                .padding(horizontal = 16.dp, vertical = 5.dp),
                            horizontalAlignment = Alignment.Start
                        ) {
                            if (mediaTitle.isNotBlank() && mediaTitle.isNotEmpty()) {
                                Text(
                                    text = mediaTitle,
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        lineHeight = 20.sp
                                    ),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Start,
                                    fontFamily = ferrariSansRegular,
                                    fontSize = 18.sp
                                )
                            }
                            if (mediaSubTitle.isNotBlank() && mediaSubTitle.isNotEmpty()) {
                                if (mediaTitle.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                }
                                Text(
                                    text = mediaSubTitle,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        lineHeight = 18.sp
                                    ),
                                    color = Color.White.copy(alpha = 0.9f),
                                    textAlign = TextAlign.Start,
                                    fontFamily = ferrariSansLight,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LoadingContent(
    loadingText: String,
    onBackButtonClick: ((Boolean) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F0F23), // Dark blue-black
                        Color(0xFF1A1A2E), // Slightly lighter blue-black
                        Color(0xFF0F0F23)  // Back to dark
                    )
                )
            )
    ) {
        // Animated background particles effect
        AnimatedParticlesBackground()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Enhanced loading indicator with pulse animation
            LoadingIndicatorWithPulse(loadingText)
        }
    }
}

/**
 * Reusable back button composable that emits a boolean event on click.
 * Positioned at top-left and visible in all states.
 * 
 * @param onBackButtonClick Callback that receives true/false boolean when button is clicked
 * @param modifier Modifier for the composable
 */
@Composable
private fun BackButton(
    onBackButtonClick: ((Boolean) -> Unit)?,
    modifier: Modifier = Modifier
) {
    if (onBackButtonClick != null) {
        IconButton(
            onClick = { onBackButtonClick(true) },
            modifier = modifier
        ) {
            Icon(
                imageVector = Icons.Filled.ArrowBack,
                contentDescription = "Back",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
private fun AnimatedParticlesBackground() {
    val infiniteTransition = rememberInfiniteTransition(label = "particles")

    val particleOffset1 = infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ), label = "particle1"
    )

    val particleOffset2 = infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ), label = "particle2"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val particleSize = 2.dp.toPx()

        // Draw floating particles
        drawCircle(
            color = Color.White.copy(alpha = 0.1f),
            radius = particleSize,
            center = Offset(particleOffset1.value % size.width, size.height * 0.3f)
        )

        drawCircle(
            color = Color(0xFF00D4FF).copy(alpha = 0.15f),
            radius = particleSize * 1.5f,
            center = Offset(particleOffset2.value % size.width, size.height * 0.7f)
        )

        drawCircle(
            color = Color.White.copy(alpha = 0.08f),
            radius = particleSize * 0.8f,
            center = Offset((particleOffset1.value * 0.7f) % size.width, size.height * 0.5f)
        )
    }
}

@Composable
private fun LoadingIndicatorWithPulse(loadingText: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "loading")

    val pulseScale = infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        ), label = "pulse"
    )

    val glowAlpha = infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        ), label = "glow"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Pulsing loading indicator with glow
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(80.dp)
        ) {
            // Glow effect
            CircularProgressIndicator(
                progress = { 1f },
                modifier = Modifier
                    .size(80.dp * pulseScale.value)
                    .alpha(glowAlpha.value),
                color = Color(0xFF00D4FF).copy(alpha = 0.3f),
                strokeWidth = 2.dp,
                trackColor = Color.Transparent
            )

            // Main loading indicator
            CircularProgressIndicator(
                modifier = Modifier.size(60.dp),
                color = Color(0xFF00D4FF),
                strokeWidth = 4.dp,
                trackColor = Color.White.copy(alpha = 0.2f)
            )

            // Inner accent ring
            CircularProgressIndicator(
                modifier = Modifier.size(40.dp),
                color = Color.White,
                strokeWidth = 2.dp,
                trackColor = Color.Transparent
            )
        }

        // Loading text with subtle animation
        Text(
            text = loadingText,
            style = MaterialTheme.typography.bodyLarge.copy(
                fontSize = 16.sp,
                letterSpacing = 0.5.sp
            ),
            color = Color.White.copy(alpha = 0.9f),
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            modifier = Modifier.alpha(glowAlpha.value)
        )
    }
}

@Composable
private fun ErrorContent(
    errorMessage: String,
    errorCode: SDKError,
    retryable: Boolean,
    retryText: String,
    onRetry: () -> Unit,
    onBackButtonClick: ((Boolean) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Animated error background effect
        ErrorBackgroundEffect()

        // Back button - always visible at top-left
        BackButton(
            onBackButtonClick = onBackButtonClick,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(top = 20.dp, start = 16.dp, end = 16.dp, bottom = 16.dp)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Error icon with pulse animation
//            ErrorIconWithPulse()

            Spacer(modifier = Modifier.height(24.dp))

            // Error title with glow effect
            Text(
                text = "Something went wrong",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontSize = 28.sp,
                    letterSpacing = 0.5.sp
                ),
                color = Color.White,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .padding(bottom = 16.dp)
            )

            // Error message with better styling
//            Text(
//                text = errorMessage,
//                style = MaterialTheme.typography.bodyLarge.copy(
//                    fontSize = 16.sp,
//                    lineHeight = 22.sp
//                ),
//                color = Color.White.copy(alpha = 0.85f),
//                fontWeight = FontWeight.Medium,
//                textAlign = TextAlign.Center,
//                modifier = Modifier
//                    .padding(horizontal = 20.dp)
//                    .padding(bottom = 8.dp)
//            )

            // Error code display (subtle)
//            Text(
//                text = "Error Code: ${errorCode.name}",
//                style = MaterialTheme.typography.bodySmall.copy(
//                    fontSize = 12.sp,
//                    letterSpacing = 0.5.sp
//                ),
//                color = Color.White.copy(alpha = 0.6f),
//                fontWeight = FontWeight.Normal,
//                textAlign = TextAlign.Center,
//                modifier = Modifier.padding(bottom = if (retryable) 32.dp else 0.dp)
//            )

            // Enhanced retry button
            if (retryable) {
                EnhancedRetryButton(retryText, onRetry)
            }
        }
    }
}

@Composable
private fun ErrorBackgroundEffect() {
    val infiniteTransition = rememberInfiniteTransition(label = "error_background")

    val waveOffset = infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ), label = "wave"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val waveHeight = size.height * 0.1f

        // Draw subtle wave pattern
        for (i in 0..5) {
            val y = size.height * 0.2f + i * size.height * 0.15f
            val offset = (waveOffset.value + i * 200f) % size.width

            // Draw wave-like patterns
            drawCircle(
                color = Color(0xFFFF6B6B).copy(alpha = 0.05f),
                radius = 40f + i * 10f,
                center = Offset(offset, y)
            )
        }
    }
}

@Composable
private fun ErrorIconWithPulse() {
    val infiniteTransition = rememberInfiniteTransition(label = "error_icon")

    val pulseScale = infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        ), label = "pulse"
    )

    val rotation = infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        ), label = "rotation"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(100.dp)
    ) {
        // Outer glow ring
        Canvas(
            modifier = Modifier
                .size(100.dp * pulseScale.value)
                .alpha(0.3f)
        ) {
            drawCircle(
                color = Color(0xFFFF6B6B),
                radius = size.minDimension / 2
            )
        }

        // Main error icon background
        Canvas(
            modifier = Modifier
                .size(80.dp)
                .rotate(rotation.value)
        ) {
            drawCircle(
                color = Color(0xFFFF6B6B).copy(alpha = 0.9f),
                radius = size.minDimension / 2
            )
        }

        // Error symbol (X)
        Canvas(modifier = Modifier.size(60.dp)) {
            val strokeWidth = 6f
            val halfStroke = strokeWidth / 2

            // Draw X symbol
            drawLine(
                color = Color.White,
                start = Offset(halfStroke, halfStroke),
                end = Offset(size.width - halfStroke, size.height - halfStroke),
                strokeWidth = strokeWidth,
                cap = StrokeCap.Round
            )

            drawLine(
                color = Color.White,
                start = Offset(size.width - halfStroke, halfStroke),
                end = Offset(halfStroke, size.height - halfStroke),
                strokeWidth = strokeWidth,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
private fun EnhancedRetryButton(retryText: String, onRetry: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val buttonScale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ), label = "button_scale"
    )

    Button(
        onClick = onRetry,
        modifier = Modifier
            .scale(buttonScale)
            .height(56.dp)
            .shadow(
                elevation = 12.dp,
                spotColor = Color(0xFF4ECDC4),
                ambientColor = Color(0xFF4ECDC4)
            ),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF4ECDC4),
            contentColor = Color(0xFF2D1B69)
        ),
        shape = RoundedCornerShape(28.dp),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = 8.dp,
            pressedElevation = 4.dp
        ),
        interactionSource = interactionSource
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = null,
                tint = Color(0xFF2D1B69)
            )
            Text(
                text = retryText,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            )
        }
    }
}

@Composable
private fun LiveStreamContent(
    viewModel: LiveStreamViewModel,
    title: String,
    description: String,
    showOverlay: Boolean,
    showPlayerControls: Boolean,
    onTap: () -> Unit,
    onClose: (() -> Unit)?,
    showCloseButton: Boolean,
    onBackButtonClick: ((Boolean) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    // Track if initial 5-second period has passed
    var initialPeriodPassed by remember { mutableStateOf(false) }
    val ferrariSansRegular = FontFamily(
        Font(R.font.ferrari_sans_regular, FontWeight.Normal)
    )
    val ferrariSansLight = FontFamily(
        Font(R.font.ferrari_sans_light, FontWeight.Normal)
    )
    // Track composable lifecycle and handle initial overlay display
    LaunchedEffect(Unit) {
        Logger.d("LiveStreamContent: Composable created/entered - starting live stream")
        
        // Show overlay initially
        viewModel.showOverlayInitially()
        
        // Auto-hide overlay after 5 seconds
        delay(5000)
        if (!initialPeriodPassed) {
            Logger.d("LiveStreamContent: Initial 5 seconds passed, hiding overlay")
            viewModel.hideOverlayAfterInitialPeriod()
            initialPeriodPassed = true
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            Logger.d("LiveStreamContent: Composable disposed/exited - stopping live stream")
            // Reset overlay state when leaving live stream
            viewModel.hideOverlayAfterInitialPeriod()
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
        // Brightcove Player - Full Screen
        BrightcovePlayerView(
            viewModel = viewModel,
            showControls = showPlayerControls,
            modifier = Modifier
                .fillMaxSize()
                .clickable { onTap() }
        )
        
        // Back button - visible initially for 5 seconds, then only when overlay is shown (on tap)
        if (showOverlay) {
            BackButton(
                onBackButtonClick = onBackButtonClick,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(top = 50.dp, start = 16.dp, end = 16.dp, bottom = 16.dp)
            )
        }
        
        // Overlay UI (shown initially for 5 seconds, then only on tap)
        // Full-width bottom overlay covering approximately bottom third of screen
        if (showOverlay) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(all = 10.dp)
                    .clickable { onTap() }
            )
            {
                // Close button in top-right corner (if enabled)
                if (showCloseButton && onClose != null) {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }
                }
                
                // Title and description overlay at bottom - full width, covers approximately bottom third
                val configuration = LocalConfiguration.current
                val screenHeight = configuration.screenHeightDp.dp
                val overlayHeight = screenHeight * 0.33f // Approximately bottom third
                if (title.isNotBlank() || description.isNotBlank()) {
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .fillMaxWidth()
                            .height(overlayHeight)
                            .background(
                                Color(0xFF17191C), // Background color #17191C
                                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                            )
                            .padding(horizontal = 20.dp, vertical = 20.dp)
                            .clickable(enabled = false) { },// Prevent click-through to background
                    ) {
                        if (title.isNotEmpty() && title.isNotBlank()) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontSize = 20.sp,
                                    lineHeight = 20.sp
                                ),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Start,
                                modifier = Modifier.fillMaxWidth(),
                                fontFamily = ferrariSansRegular,
                                fontSize = 18.sp
                            )
                        }
                        if (description.isNotEmpty() && description.isNotBlank()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = description,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontSize = 16.sp,
                                    lineHeight = 24.sp
                                ),
                                color = Color.White.copy(alpha = 0.95f),
                                textAlign = TextAlign.Start,
                                modifier = Modifier.fillMaxWidth(),
                                fontSize = 12.sp,
                                fontFamily = ferrariSansLight
                            )
                        }
                    }
                }
            }
        }
    }
}

