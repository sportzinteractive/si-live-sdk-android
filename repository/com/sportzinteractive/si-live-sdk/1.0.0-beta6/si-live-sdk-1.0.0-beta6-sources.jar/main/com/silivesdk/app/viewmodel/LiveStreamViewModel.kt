package com.silivesdk.app.viewmodel

import android.annotation.SuppressLint
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.brightcove.player.edge.VideoListener
import com.brightcove.player.model.Video
import com.brightcove.player.network.HttpRequestConfig
import com.brightcove.player.view.BrightcoveExoPlayerVideoView
import android.os.Build
import com.silivesdk.app.BrightcoveLiveStreamSDK
import com.silivesdk.app.config.StreamConfigData
import com.silivesdk.app.generateBrightcoveJWT
import com.silivesdk.app.loadPrivateKeyFromPem
import com.silivesdk.app.model.LiveStreamState
import com.silivesdk.app.model.PlayerEvent
import com.silivesdk.app.model.SDKError
import com.silivesdk.app.network.NetworkMonitor
import com.silivesdk.app.ui.Logger
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.net.ConnectException
import java.net.UnknownHostException
import java.security.PrivateKey
import kotlin.math.pow


/**
 * ViewModel for managing live stream state and Brightcove video playback.
 */
class LiveStreamViewModel(application: Application) : AndroidViewModel(application) {
    
    private val networkMonitor = NetworkMonitor(application)
    
    // Store reference to player view for Catalog creation
    @SuppressLint("StaticFieldLeak")
    private var playerView: BrightcoveExoPlayerVideoView? = null
    
    // Cache the private key to avoid loading it multiple times
    private var cachedPrivateKey: PrivateKey? = null
    
    private val _streamState = MutableStateFlow<LiveStreamState>(LiveStreamState.Loading)
    val streamState: StateFlow<LiveStreamState> = _streamState.asStateFlow()
    
    private val _showOverlay = MutableStateFlow(false)
    val showOverlay: StateFlow<Boolean> = _showOverlay.asStateFlow()
    
    private val _video = MutableStateFlow<Video?>(null)
    val video: StateFlow<Video?> = _video.asStateFlow()
    
    private val _playerEvent = MutableStateFlow<PlayerEvent?>(null)
    val playerEvent: StateFlow<PlayerEvent?> = _playerEvent.asStateFlow()
    
    private var retryAttempts = 0
    private var isRetrying = false
    
    /**
     * Set the player view reference for Catalog operations.
     * This should only be called when EventEmitter is confirmed available.
     * 
     * @param view BrightcoveExoPlayerVideoView instance
     * @param eventEmitterReady Whether the EventEmitter has been confirmed available (default: true)
     */
    fun setPlayerView(view: BrightcoveExoPlayerVideoView?, eventEmitterReady: Boolean = true) {
        val wasNull = playerView == null
        playerView = view
        
        if (view != null && wasNull) {
            if (eventEmitterReady) {
                // EventEmitter is confirmed ready, check stream status immediately
                if (BrightcoveLiveStreamSDK.getConfig().debug) {
                    Logger.d("Player view set with EventEmitter ready, checking stream status")
                }
                checkLiveStreamStatus()
            } else {
                // EventEmitter not ready yet, wait for it
                if (BrightcoveLiveStreamSDK.getConfig().debug) {
                    Logger.d("Player view set but EventEmitter not ready, waiting...")
                }
                viewModelScope.launch {
                    waitForEventEmitterAndCheck()
                }
            }
        } else if (view != null && _streamState.value is LiveStreamState.Loading && eventEmitterReady) {
            // Player view available and in loading state - check status
            checkLiveStreamStatus()
        }
    }
    
    /**
     * Wait for EventEmitter to be available, then check stream status.
     */
    private suspend fun waitForEventEmitterAndCheck() {
        var attempts = 0
        val maxAttempts = 10 // Try for up to 1 second (20 * 50ms) - reduced for faster loading
        
        while (attempts < maxAttempts) {
            val eventEmitter = playerView?.eventEmitter
            if (eventEmitter != null) {
                if (BrightcoveLiveStreamSDK.getConfig().debug) {
                    Logger.d("EventEmitter is now available, checking stream status")
                }
                checkLiveStreamStatus()
                return
            }
            
            attempts++
            delay(50) // Wait 50ms before checking again (reduced from 100ms for faster loading)
            
            if (BrightcoveLiveStreamSDK.getConfig().debug && attempts % 5 == 0) {
                Logger.d("Waiting for EventEmitter... attempt $attempts/$maxAttempts")
            }
        }
        
        // If EventEmitter still not available after max attempts, try checking anyway
        if (BrightcoveLiveStreamSDK.getConfig().debug) {
            Logger.w("EventEmitter still not available after ${maxAttempts} attempts, checking anyway")
        }
        checkLiveStreamStatus()
    }
    
    init {
        // Monitor network connectivity
        viewModelScope.launch {
            networkMonitor.isNetworkAvailable().collectLatest { isAvailable ->
                if (!isAvailable && _streamState.value !is LiveStreamState.Error) {
                    _streamState.value = LiveStreamState.Error(
                        errorMessage = "No internet connection",
                        errorCode = SDKError.NETWORK_ERROR,
                        retryable = true
                    )
                } else if (isAvailable && _streamState.value is LiveStreamState.Error) {
                    // Network restored, retry if in error state
                    if ((_streamState.value as LiveStreamState.Error).retryable) {
                        retry()
                    }
                }
            }
        }
        
        // Check if we should initialize with config state immediately (for config-driven behavior)
        viewModelScope.launch {
            try {
                if (BrightcoveLiveStreamSDK.isInitialized()) {
                    val config = BrightcoveLiveStreamSDK.getConfig()
                    if (config.configState.isNotBlank()) {
                        val configStateLower = config.configState.lowercase().trim()
                        if (configStateLower == "prelive") {
                            // Immediately show pre-live content from config
                            _streamState.value = LiveStreamState.PreLive(
                                mediaType = config.configMediaType,
                                mediaUrl = config.configMediaUrl,
                                mediaTitle = config.configMediaTitle,
                                mediaSubTitle = config.configMediaSubTitle,
                                mediaLoop = config.configMediaLoop
                            )
                            if (config.debug) {
                                Logger.d("Initialized with preLive state from config")
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                // SDK not initialized yet, will be handled when setPlayerView is called
                if (BrightcoveLiveStreamSDK.isInitialized() && BrightcoveLiveStreamSDK.getConfig().debug) {
                    Logger.d("Could not initialize with config state: ${e.message}")
                }
            }
        }
        
        // Don't check stream status here - wait for player view to be set
        // checkLiveStreamStatus() will be called when playerView is set via setPlayerView()
        startPeriodicCheck()
    }
    
    /**
     * Check if the live stream is available and update state accordingly.
     */
    private fun checkLiveStreamStatus() {
        viewModelScope.launch {
            // Check network availability first
            if (!networkMonitor.isNetworkAvailableNow()) {
                _streamState.value = LiveStreamState.Error(
                    errorMessage = "No internet connection",
                    errorCode = SDKError.NETWORK_ERROR,
                    retryable = true
                )
                return@launch
            }
            
            try {
                val config = BrightcoveLiveStreamSDK.getConfig()
                
                // If using config-driven behavior, check config state first
                    // Config-driven behavior is enabled
                    if (config.configState.isBlank()) {
                        // Config state is missing/empty - this means config failed to load
                        // Show error or PreLive with empty values, don't check Brightcove video
                        if (BrightcoveLiveStreamSDK.getConfig().debug) {
                            Logger.w("Config-driven mode but configState is blank - configuration may be missing or invalid")
                        }
                        
                        // Show PreLive with available config values (may be empty)
                        if (_streamState.value is LiveStreamState.Loading) {
//                            _streamState.value = LiveStreamState.PreLive(
//                                mediaType = config.configMediaType,
//                                mediaUrl = config.configMediaUrl,
//                                mediaTitle = config.configMediaTitle,
//                                mediaLoop = config.configMediaLoop
//                            )
                            _streamState.value = LiveStreamState.Error(
                                errorMessage = "Something Went Wrong",
                                errorCode = SDKError.UNKNOWN_ERROR,
                                retryable = false
                            )
                        }
                        return@launch // Don't check Brightcove video when config is missing
                    }
                    
                    val configStateLower = config.configState.lowercase().trim()
                    
                    when (configStateLower) {
                        "prelive","postlive"-> {
                            // Config says pre-live: show configured media immediately
                            if (BrightcoveLiveStreamSDK.getConfig().debug) {
                                Logger.d("Config state is preLive/postlive - showing configured media")
                            }
                            
                            val currentState = _streamState.value
                            val needsUpdate = when (currentState) {
                                is LiveStreamState.Loading -> true
                                is LiveStreamState.PreLive -> {
                                    // Check if any configuration data has changed
                                    currentState.mediaType != config.configMediaType ||
                                    currentState.mediaUrl != config.configMediaUrl ||
                                    currentState.mediaTitle != config.configMediaTitle ||
                                    currentState.mediaSubTitle != config.configMediaSubTitle ||
                                    currentState.mediaLoop != config.configMediaLoop
                                }
                                else -> true // Not in Loading or PreLive, need to update
                            }
                            
                            if (needsUpdate) {
                                if (BrightcoveLiveStreamSDK.getConfig().debug && currentState is LiveStreamState.PreLive) {
                                    Logger.d("PreLive/postlive config data changed, updating state")
                                }
                                _streamState.value = LiveStreamState.PreLive(
                                    mediaType = config.configMediaType,
                                    mediaUrl = config.configMediaUrl,
                                    mediaTitle = config.configMediaTitle,
                                    mediaLoop = config.configMediaLoop
                                )
                            }
                            return@launch // Don't check Brightcove video for preLive state
                        }
                        "live" -> {
                            // Config says live: check Brightcove video
                            if (BrightcoveLiveStreamSDK.getConfig().debug) {
                                Logger.d("Config state is live - checking Brightcove video")
                            }
                            // Continue to Brightcove video check below
                        }
//                        "postlive" -> {
//                            // Config says post-live: show error or end state
//                            if (BrightcoveLiveStreamSDK.getConfig().debug) {
//                                Logger.d("Config state is postLive")
//                            }
//                            // Handle post-live state if needed
//                            return@launch
//                        }
                        else -> {
                            // Unknown state, show PreLive with config values instead of checking Brightcove
                            if (BrightcoveLiveStreamSDK.getConfig().debug) {
                                Logger.w("Unknown config state: $configStateLower, showing PreLive with config values")
                            }
                            if (_streamState.value is LiveStreamState.Loading) {
                                _streamState.value = LiveStreamState.PreLive(
                                    mediaType = config.configMediaType,
                                    mediaUrl = config.configMediaUrl,
                                    mediaTitle = config.configMediaTitle,
                                    mediaLoop = config.configMediaLoop
                                )
                            }
                            return@launch // Don't check Brightcove video for unknown config state
                        }
                    }
                
                // Check Brightcove video (for live state or when not using config)
                val catalog = BrightcoveLiveStreamSDK.getBrightcoveEmitter(playerView)

                if (catalog == null) {
                    // Player view not available yet, wait for it
                    if (BrightcoveLiveStreamSDK.getConfig().debug) {
                        Logger.d("Catalog not available - waiting for player view")
                    }
                    // Don't change state - stay in Loading or current state
                    return@launch
                }

                val effectiveVideoId = config.getEffectiveVideoId()
                val accountId = config.getBrightcoveAccountId()
                
                // Try to get the actual base URL from Catalog instance
                val baseUrl = try {
                    val baseUrlField = catalog.javaClass.getDeclaredField("baseURL")
                    baseUrlField.isAccessible = true
                    baseUrlField.get(catalog) as? String ?: "https://edge.api.brightcove.com/playback/v1"
                } catch (e: Exception) {
                    // Fallback to default if reflection fails
                    "https://edge.api.brightcove.com/playback/v1"
                }
                
                val fullApiUrl = "$baseUrl/accounts/$accountId/videos/$effectiveVideoId"
                
                if (BrightcoveLiveStreamSDK.getConfig().debug) {
                    Logger.d("=== Brightcove API Call ===")
                    Logger.d("HTTP Method: GET")
                    Logger.d("Base URL: $baseUrl")
                    Logger.d("Account ID: $accountId")
                    Logger.d("Video ID: $effectiveVideoId")
                    Logger.d("Full API Endpoint: $fullApiUrl")
                    Logger.d("Policy Key: ${config.getBrightcovePolicyKey()}")
                    Logger.d("Request Headers: Authorization: Bearer ${config.getBrightcovePolicyKey()}")
                } else {
                    // Always log API calls even if debug is off (for troubleshooting)
                    Logger.d("Brightcove API Call: GET $fullApiUrl")
                }

                // Load private key and generate JWT token
                // Option 1: Load from assets folder (recommended for Android)
                // Place private.pem in app/src/main/assets/private.pem
                val privateKeyPath = "private.pem"
                
                // Option 2: Load from absolute file path (for development/testing)
                // Uncomment the line below and comment the line above if you want to use absolute path
                // val privateKeyPath = "C:\\Users\\Nitesh.kukreja\\Downloads\\private.pem"
                
                val token = try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        // Load private key (use cached version if available)
                        val privateKey = try {
                            cachedPrivateKey ?: run {
                                Logger.d("Loading private key from: $privateKeyPath")
                                val loadedKey =
                                    loadPrivateKeyFromPem(privateKeyPath, getApplication())
                                cachedPrivateKey = loadedKey
                                Logger.d("Private key loaded successfully")
                                loadedKey
                            }
                        } catch (keyError: Exception) {
                            Logger.e("=== PRIVATE KEY LOADING ERROR ===")
                            Logger.e("Error Type: ${keyError.javaClass.simpleName}")
                            Logger.e("Error Message: ${keyError.message}")
                            Logger.e("Private Key Path Attempted: $privateKeyPath")
                            Logger.e("Stack Trace:")
                            keyError.printStackTrace()
                            Logger.e("===================================")
                            throw keyError
                        }

                        try {
                            val jwtToken =
                                generateBrightcoveJWT(privateKey, config.getBrightcoveAccountId())
                            Logger.d("JWT token generated successfully (length: ${jwtToken.length})")
                            jwtToken
                        } catch (jwtError: Exception) {
                            Logger.e("=== JWT GENERATION ERROR ===")
                            Logger.e("Error Type: ${jwtError.javaClass.simpleName}")
                            Logger.e("Error Message: ${jwtError.message}")
                            Logger.e("Account ID: ${config.getBrightcoveAccountId()}")
                            Logger.e("Stack Trace:")
                            jwtError.printStackTrace()
                            Logger.e("=============================")
                            throw jwtError
                        }
                    } else {
                        Logger.w("JWT generation requires Android API 26+ (current: ${Build.VERSION.SDK_INT}), falling back to hardcoded token")
                        // Fallback for older Android versions
                        "ewogICJ0eXBlIjogIkpXVCIsCiAgImFsZyI6ICJSUzI1NiIKfQ.ewogICJhY2NpZCI6ICI2NDE2MTAwNzg3MDAxIiwKICAiaWF0IjogMTc2NzYxMTM2NiwKICAiZXhwIjogMTc2NzYxNDk2Ngp9.H1mfSeuiv2bm3V8MalufFKjLiJ5pr1nIOCHdkeFcvM_9xWpaCF0aAqNjsPwpjKnWFZFU6bAAGcJdb_vp9wRa-rYnnvZswIqbGCrd3U7ZB3Xd9yxb4MgSZZ2JoWeeOd4U4H9YLQ1LAzrw2SlCZkFkJZwd13DbqnqoITis6NWZt3P1sButZZEhoKWECDhiqySXlnTjMlbtOuiwHfXCj3wEAdV2qftCvxIbJM81SmNUIJXvkH-IKPsAR2L0ahICHNehfZKDgP_CPiBas7aQql3KiEZvi_wvkwdj66RdgLrcAr9eAnN--DSk94wN6xup6X3t10V_goHI_AYexZLUUv23aA"
                    }
                }
                catch (e: Exception) {
                    Logger.e("=== JWT TOKEN GENERATION FAILED ===")
                    Logger.e("Error Type: ${e.javaClass.simpleName}")
                    Logger.e("Error Message: ${e.message ?: "Unknown error"}")
                    Logger.e("Private Key Path Attempted: $privateKeyPath")
                    Logger.e("Account ID: ${config.getBrightcoveAccountId()}")
                    Logger.e("Android API Level: ${Build.VERSION.SDK_INT}")
                    Logger.e("Full Exception:")
                    e.printStackTrace()
                    Logger.e("===================================")
                    Logger.e("Falling back to hardcoded token")
                    Logger.e("Tip: For Android devices, place private.pem in app/src/main/assets/ and use path 'private.pem'")
                    // Fallback to hardcoded token if key loading fails
                    "ewogICJ0eXBlIjogIkpXVCIsCiAgImFsZyI6ICJSUzI1NiIKfQ.ewogICJhY2NpZCI6ICI2NDE2MTAwNzg3MDAxIiwKICAiaWF0IjogMTc2NzYxMTM2NiwKICAiZXhwIjogMTc2NzYxNDk2Ngp9.H1mfSeuiv2bm3V8MalufFKjLiJ5pr1nIOCHdkeFcvM_9xWpaCF0aAqNjsPwpjKnWFZFU6bAAGcJdb_vp9wRa-rYnnvZswIqbGCrd3U7ZB3Xd9yxb4MgSZZ2JoWeeOd4U4H9YLQ1LAzrw2SlCZkFkJZwd13DbqnqoITis6NWZt3P1sButZZEhoKWECDhiqySXlnTjMlbtOuiwHfXCj3wEAdV2qftCvxIbJM81SmNUIJXvkH-IKPsAR2L0ahICHNehfZKDgP_CPiBas7aQql3KiEZvi_wvkwdj66RdgLrcAr9eAnN--DSk94wN6xup6X3t10V_goHI_AYexZLUUv23aA"
                }
                
                if (BrightcoveLiveStreamSDK.getConfig().debug) {
                    Logger.d("Generated JWT token: $token")
                }


                val httpRequestConfig = HttpRequestConfig.Builder()
                    .setBrightcoveAuthorizationToken(token)
                    .build()
                
                Logger.d("=== Brightcove API Request ===")
                Logger.d("Method: GET")
                Logger.d("Endpoint: $fullApiUrl")
                Logger.d("Video ID: $effectiveVideoId")
                Logger.d("Account ID: $accountId")
                Logger.d("JWT Token Length: ${token.length}")
                Logger.d("Request Config: Authorization token set")
                
                catalog.findVideoByID(effectiveVideoId, object : VideoListener() {
                    override fun onVideo(video: Video) {
                        Logger.d("=== Brightcove API Response ===")
                        Logger.d("Status: SUCCESS (200 OK)")
                        Logger.d("Video ID: ${video.id}")
                        Logger.d("Video Name: ${video.name}")
                        Logger.d("Video Description: ${video.description}")
                        Logger.d("Video Duration: ${video.duration}")
                        Logger.d("================================")
                        
                        _video.value = video
                        retryAttempts = 0 // Reset retry attempts on success
                        
                        // If video is found and available, switch to Live state
                        // Use liveMediaTitle and liveMediaSubTitle from config if available
                        if (_streamState.value !is LiveStreamState.Live) {
                            val config = BrightcoveLiveStreamSDK.getConfig()
//                            val liveTitle = if (config.configLiveMediaTitle.isNotBlank()) {
//                                config.configLiveMediaTitle
//                            } else {
//                                video.name ?: "Live Stream"
//                            }
//                            val liveSubTitle = if (config.configLiveMediaSubTitle.isNotBlank()) {
//                                config.configLiveMediaSubTitle
//                            } else {
//                                video.description ?: ""
//                            }
                            
                            _streamState.value = LiveStreamState.Live(
                                title = "",
                                description = ""
                            )
                            _playerEvent.value = PlayerEvent.VideoLoaded
                        }
                    }
                    
                    override fun onError(error: String) {
                        Logger.e("=== Brightcove API Error ===")
                        Logger.e("Status: ERROR")
                        Logger.e("Error Message: $error")
                        Logger.e("API Endpoint: $fullApiUrl")
                        Logger.e("Video ID Requested: $effectiveVideoId")
                        Logger.e("Account ID: $accountId")
                        Logger.e("Base URL: $baseUrl")
                        Logger.e("JWT Token Used: ${if (token.length > 50) token.substring(0, 50) + "..." else token}")
                        Logger.e("Request Time: ${System.currentTimeMillis()}")
                        
                        // Try to parse error details
                        try {
                            // Check for common error patterns
                            when {
                                error.contains("404", ignoreCase = true) || error.contains("not found", ignoreCase = true) -> {
                                    Logger.e("Error Type: Video Not Found (404)")
                                    Logger.e("This is expected if video is not yet available (prelive state)")
                                }
                                error.contains("401", ignoreCase = true) || error.contains("unauthorized", ignoreCase = true) -> {
                                    Logger.e("Error Type: Unauthorized (401)")
                                    Logger.e("Possible causes: Invalid JWT token, expired token, or invalid account ID")
                                }
                                error.contains("403", ignoreCase = true) || error.contains("forbidden", ignoreCase = true) -> {
                                    Logger.e("Error Type: Forbidden (403)")
                                    Logger.e("Possible causes: Insufficient permissions or policy key issue")
                                }
                                error.contains("500", ignoreCase = true) || error.contains("server error", ignoreCase = true) -> {
                                    Logger.e("Error Type: Server Error (500)")
                                    Logger.e("Brightcove server error - may be temporary")
                                }
                                error.contains("network", ignoreCase = true) || error.contains("timeout", ignoreCase = true) -> {
                                    Logger.e("Error Type: Network Error")
                                    Logger.e("Possible causes: No internet connection or network timeout")
                                }
                                else -> {
                                    Logger.e("Error Type: Unknown")
                                    Logger.e("Full error details: $error")
                                }
                            }
                        } catch (e: Exception) {
                            Logger.e("Could not parse error details: ${e.message}")
                        }
                        
                        Logger.e("=================================")
                        
                        retryAttempts = 0 // Reset for video not found (expected before stream starts)
                        
                        // Video not found or not available yet, stay in PreLive state
                        // This is expected behavior when stream hasn't started
                        if (_streamState.value is LiveStreamState.Loading) {
                            val config = BrightcoveLiveStreamSDK.getConfig()
                            _streamState.value = LiveStreamState.PreLive(
                                mediaType = config.configMediaType,
                                mediaUrl = config.configMediaUrl,
                                mediaTitle = config.configMediaTitle,
                                mediaSubTitle = config.configMediaSubTitle,
                                mediaLoop = config.configMediaLoop
                            )
                        }
                    }
                })
            } catch (e: Exception) {
                Logger.e("=== Brightcove API Call Exception ===")
                Logger.e("Error Type: ${e.javaClass.simpleName}")
                Logger.e("Error Message: ${e.message ?: "Unknown error"}")
                Logger.e("Stack Trace:")
                e.printStackTrace()
                Logger.e("=====================================")
                handleError(e)
            }
        }
    }
    
    /**
     * Handle errors with retry logic.
     */
    private fun handleError(e: Exception) {
        val config = BrightcoveLiveStreamSDK.getConfig()
        val errorCode = when (e) {
            is UnknownHostException, is ConnectException -> SDKError.NETWORK_ERROR
            is IllegalStateException -> SDKError.INITIALIZATION_ERROR
            else -> SDKError.UNKNOWN_ERROR
        }
        
        val errorMessage = when (errorCode) {
            SDKError.NETWORK_ERROR -> "Network error: ${e.message ?: "Unable to connect"}"
            SDKError.INITIALIZATION_ERROR -> "Initialization error: ${e.message ?: "SDK not properly initialized"}"
            else -> "An error occurred: ${e.message ?: "Unknown error"}"
        }
        
        if (config.debug) {
            Logger.e(errorMessage, e)
        }
        
        val retryable = errorCode == SDKError.NETWORK_ERROR &&
                retryAttempts < config.maxRetryAttempts
        
        _streamState.value = LiveStreamState.Error(
            errorMessage = errorMessage,
            errorCode = errorCode,
            retryable = retryable
        )
        
        // Auto-retry if enabled
        if (config.autoRetryOnError && retryable && !isRetrying) {
            retry()
        }
    }
    
    /**
     * Start periodic checking for live stream availability.
     */
    private fun startPeriodicCheck() {
        viewModelScope.launch {
            while (true) {
                val config = BrightcoveLiveStreamSDK.getConfig()
                val pollingInterval = config.getEffectivePollingInterval()
                delay(pollingInterval)
                Logger.d("Polling Interval: $pollingInterval")
                when (val currentState = _streamState.value) {
                    is LiveStreamState.PreLive, is LiveStreamState.Loading -> {
                        checkLiveStreamStatus()
                    }
                    is LiveStreamState.Error -> {
                        // Continue checking if retryable
                        if (currentState.retryable && networkMonitor.isNetworkAvailableNow()) {
                            checkLiveStreamStatus()
                        }
                    }
                    is LiveStreamState.Live -> {
                        // Only stop checking if not using config (state=true)
                        // If using config (state=false), continue checking to update state

                            break
                    }
                }
            }
        }
    }
    
    /**
     * Retry loading the stream.
     */
    fun retry() {
        if (isRetrying) return
        
        val config = BrightcoveLiveStreamSDK.getConfig()
        if (retryAttempts >= config.maxRetryAttempts) {
            _streamState.value = LiveStreamState.Error(
                errorMessage = "Maximum retry attempts reached",
                errorCode = SDKError.NETWORK_ERROR,
                retryable = false
            )
            return
        }
        
        isRetrying = true
        retryAttempts++
        
        viewModelScope.launch {
            // Exponential backoff
            val backoffDelay = (1000 * config.retryBackoffMultiplier.pow((retryAttempts - 1).toDouble())).toLong()
            delay(backoffDelay)
            
            checkLiveStreamStatus()
            isRetrying = false
        }
    }
    
    /**
     * Toggle the overlay UI visibility.
     */
    fun toggleOverlay() {
        _showOverlay.value = !_showOverlay.value
    }
    
    /**
     * Show overlay initially when live stream starts.
     */
    fun showOverlayInitially() {
        _showOverlay.value = true
    }
    
    /**
     * Hide overlay after initial 5-second period.
     */
    fun hideOverlayAfterInitialPeriod() {
        _showOverlay.value = false
    }
    
    /**
     * Get the current video for playback.
     */
    fun getVideo(): Video? = _video.value
    
    /**
     * Emit a player event.
     */
    fun emitPlayerEvent(event: PlayerEvent) {
        _playerEvent.value = event
    }

    override fun onCleared() {
        super.onCleared()
        // Ensure Brightcove player is properly released when ViewModel is cleared
        stopAndReleaseBrightcovePlayer()
    }

    /**
     * Stop and release the Brightcove player.
     */
    private fun stopAndReleaseBrightcovePlayer() {
        try {
            playerView?.let { view ->
                if (BrightcoveLiveStreamSDK.getConfig().debug) {
                    Logger.d("Stopping and releasing Brightcove player")
                }

                // Stop playback
                view.pause()
                view.stopPlayback()

                // Clear current video
                view.clear()

                // Reset player view state
                _video.value = null
                _playerEvent.value = null

                if (BrightcoveLiveStreamSDK.getConfig().debug) {
                    Logger.d("Brightcove player stopped and released successfully")
                }
            }
        } catch (e: Exception) {
            if (BrightcoveLiveStreamSDK.getConfig().debug) {
                Logger.e("Error stopping Brightcove player: ${e.message}", e)
            }
        }
    }

    /**
     * Update configuration and handle state transitions.
     */
    fun updateConfiguration(newConfig: StreamConfigData) {
        if (BrightcoveLiveStreamSDK.getConfig().debug) {
            Logger.d("LiveStreamViewModel: Configuration updated - liveVideoId: ${newConfig.liveVideoId}, state: ${newConfig.state}, mediaType: ${newConfig.mediaType}, mediaUrl: ${newConfig.mediaUrl}")
        }

        val newState = newConfig.state.lowercase().trim()
        val currentState = _streamState.value

        // Handle state transitions based on new config
        when (newState) {
            "prelive", "postlive" -> {
                // Check if we need to update: either not in PreLive state, or data has changed
                val needsUpdate = when (currentState) {
                    is LiveStreamState.PreLive -> {
                        // Check if any configuration data has changed
                        currentState.mediaType != newConfig.mediaType ||
                        currentState.mediaUrl != newConfig.mediaUrl ||
                        currentState.mediaTitle != newConfig.mediaTitle ||
                        currentState.mediaSubTitle != newConfig.mediaSubTitle ||
                        currentState.mediaLoop != newConfig.mediaLoop
                    }
                    else -> true // Not in PreLive state, need to transition
                }
                
                if (needsUpdate) {
                    if (BrightcoveLiveStreamSDK.getConfig().debug) {
                        if (currentState is LiveStreamState.PreLive) {
                            Logger.d("Config changed for prelive/postlive - updating PreLive state with new locale data")
                        } else {
                            Logger.d("Config changed to prelive/postlive - transitioning from ${currentState::class.simpleName} to PreLive")
                        }
                    }

                    // Stop and release Brightcove player if currently playing
                    stopAndReleaseBrightcovePlayer()

                    // Clear video state
                    _video.value = null

                    // Transition to PreLive state or update existing PreLive state
                    val newPreLiveState = LiveStreamState.PreLive(
                        mediaType = newConfig.mediaType,
                        mediaUrl = newConfig.mediaUrl,
                        mediaTitle = newConfig.mediaTitle,
                        mediaSubTitle = newConfig.mediaSubTitle,
                        mediaLoop = newConfig.mediaLoop
                    )
                    _streamState.value = newPreLiveState
                    if (BrightcoveLiveStreamSDK.getConfig().debug) {
                        Logger.d("LiveStreamViewModel: Updated PreLive state - mediaType: ${newConfig.mediaType}, mediaUrl: ${newConfig.mediaUrl}, mediaTitle: ${newConfig.mediaTitle}")
                    }
                } else {
                    if (BrightcoveLiveStreamSDK.getConfig().debug) {
                        Logger.d("LiveStreamViewModel: PreLive state unchanged, skipping update")
                    }
                }
            }
            "live" -> {
                // If config says live, ensure clean state and start Brightcove video
                if (currentState !is LiveStreamState.Live) {
                    if (BrightcoveLiveStreamSDK.getConfig().debug) {
                        Logger.d("Config changed to live - transitioning to Live state")
                    }

                    // Stop any existing player before starting live stream
                    stopAndReleaseBrightcovePlayer()

                    // Trigger immediate video check to start live stream
                    viewModelScope.launch {
                        checkLiveStreamStatus()
                    }
                } else {
                    // Already in Live state, but update title/subtitle if they changed
                    val currentLiveState = currentState as LiveStreamState.Live
                    if (currentLiveState.title != newConfig.liveMediaTitle || 
                        currentLiveState.description != newConfig.liveMediaSubTitle) {
                        if (BrightcoveLiveStreamSDK.getConfig().debug) {
                            Logger.d("Live state title/subtitle changed, updating overlay")
                        }
                        _streamState.value = LiveStreamState.Live(
                            title = newConfig.liveMediaTitle.ifBlank { currentLiveState.title },
                            description = newConfig.liveMediaSubTitle.ifBlank { currentLiveState.description }
                        )
                    }
                }
            }
            else -> {
                if (BrightcoveLiveStreamSDK.getConfig().debug) {
                    Logger.w("Unknown config state: $newState")
                }
            }
        }
    }
}

