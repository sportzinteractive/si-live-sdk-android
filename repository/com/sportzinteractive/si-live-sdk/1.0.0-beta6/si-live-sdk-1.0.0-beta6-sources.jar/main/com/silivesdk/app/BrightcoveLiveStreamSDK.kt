package com.silivesdk.app

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.annotation.RequiresApi
import com.brightcove.player.edge.Catalog
import com.brightcove.player.event.EventEmitter
import com.brightcove.player.view.BrightcoveExoPlayerVideoView
import com.silivesdk.app.analytics.AnalyticsManager
import com.silivesdk.app.config.ConfigurationManager
import com.silivesdk.app.config.SDKConfig
import com.silivesdk.app.config.StreamConfigData
import com.silivesdk.app.model.Environment
import com.silivesdk.app.model.MediaType
import com.silivesdk.app.model.EventType as SdkEventType
import com.silivesdk.app.ui.Logger
import org.json.JSONObject
import java.io.File
import java.io.FileNotFoundException
import java.security.KeyFactory
import java.security.PrivateKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.Signature
import java.util.Base64
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Listener interface for configuration changes.
 */
interface ConfigurationChangeListener {
    /**
     * Called when configuration is updated from API.
     * @param newConfig The new configuration data
     */
    fun onConfigurationChanged(newConfig: StreamConfigData)
}

/**
 * Main SDK initialization class.
 * Must be initialized once per app lifecycle before using LiveStreamScreen.
 */
object BrightcoveLiveStreamSDK {

    private var isInitialized = false
    private var sdkConfig: SDKConfig? = null
    @SuppressLint("StaticFieldLeak")
    private var analyticsManager: AnalyticsManager? = null
    private var standaloneEventEmitter: EventEmitter? = null

    // Periodic config updates
    private var configUpdateHandler: Handler? = null
    private var configUpdateRunnable: Runnable? = null
    private var isPeriodicUpdatesEnabled = false

    // Configuration change listeners
    private val configChangeListeners = CopyOnWriteArrayList<ConfigurationChangeListener>()


    /**
     * Initialize the SDK with required parameters.
     *
     * @param context Application context
     * @param eventType Required event type (MOBILE/CAMERA)
     * @param environment Required environment (PROD/NON_PROD)
     * @param locales Required locales identifier for configuration
     * @param state Configuration behavior toggle: true = existing behavior, false = config-driven behavior
     * @param debug Optional debug flag (default: false)
     * @throws IllegalStateException if SDK is already initialized
     */
    @JvmStatic
    fun initialize(
        context: Context,
        eventType: SdkEventType,
        environment: Environment,
        locales: String,
        debug: Boolean
    ) {
        initialize(
            context = context,
            eventType = eventType,
            environment = environment,
            locales = locales,
            debug = debug,
            autoRetryOnError = true,
            maxRetryAttempts = 3,
            retryBackoffMultiplier = 2.0
        )
    }
    
    /**
     * Initialize the SDK with advanced configuration options.
     *
     * @param context Application context
     * @param eventType Required event type (MOBILE/CAMERA)
     * @param environment Required environment (PROD/NON_PROD)
     * @param locales Required locales identifier for configuration
     * @param state Configuration behavior toggle: true = existing behavior, false = config-driven behavior
     * @param debug Optional debug flag (default: false)
     * @param autoRetryOnError Whether to automatically retry on errors (default: true)
     * @param maxRetryAttempts Maximum number of retry attempts (default: 3)
     * @param retryBackoffMultiplier Multiplier for exponential backoff (default: 2.0)
     * @throws IllegalStateException if SDK is already initialized
     */
    @JvmStatic
    fun initialize(
        context: Context,
        eventType: SdkEventType,
        environment: Environment,
        locales: String,
        debug: Boolean = false,
        autoRetryOnError: Boolean = true,
        maxRetryAttempts: Int = 3,
        retryBackoffMultiplier: Double = 2.0
    ) {
        if (isInitialized) {
            throw IllegalStateException("BrightcoveLiveStreamSDK is already initialized. Initialize only once per app lifecycle.")
        }

        val appContext = context.applicationContext

        // Load configuration if state=false (config-driven behavior)
        var configLiveVideoId = ""
        var configLiveVideoOrientation = "portrait"
        var configLiveMediaTitle = ""
        var configLiveMediaSubTitle = ""
        var configState = ""
        var configMediaType = MediaType.IMAGE
        var configMediaUrl = ""
        var configMediaTitle = ""
        var configMediaSubTitle = ""
        var configMediaLoop = true
        var configIntervals = emptyMap<String, Int>()

            val configManager = ConfigurationManager.Companion.getInstance()
//            val apiUrl = "https://squirrel-prepared-marlin.ngrok-free.app/stream_config.json"
              val apiUrl = "https://stg-spz.sportz.io/static-assets/feeds/config.json?v="+currenttimemillis()


            // Try API first, fallback to local assets if API fails
            var configResult = configManager.loadConfigurationFromApi(apiUrl, debug)
            if (configResult.isFailure && debug) {
                Logger.w("API configuration loading failed, falling back to local assets")
                configResult = configManager.loadConfiguration(appContext, debug)
            }

            if (configResult.isSuccess) {
                val streamConfigResult = configManager.getConfiguration(eventType, environment, locales,debug)
                if (streamConfigResult.isSuccess) {
                    val streamConfig = streamConfigResult.getOrThrow()
                    configLiveVideoId = streamConfig.liveVideoId
                    configLiveVideoOrientation = streamConfig.liveVideoOrientation
                    configLiveMediaTitle = streamConfig.liveMediaTitle
                    configLiveMediaSubTitle = streamConfig.liveMediaSubTitle
                    configState = streamConfig.state
                    configMediaType = streamConfig.mediaType
                    configMediaUrl = streamConfig.mediaUrl
                    configMediaTitle = streamConfig.mediaTitle
                    configMediaSubTitle = streamConfig.mediaSubTitle
                    configMediaLoop = streamConfig.mediaLoop
                    configIntervals = streamConfig.intervals

                    if (debug) {
                        Logger.d("Loaded configuration: liveVideoId=$configLiveVideoId, liveVideoOrientation=$configLiveVideoOrientation, state=$configState, mediaType=$configMediaType, intervals=$configIntervals")
                    }
                } else {
                    if (debug) {
                        Logger.w("Failed to get configuration for locales '$locales': ${streamConfigResult.exceptionOrNull()?.message}")
                    }
                    // Continue with default values
                }
            } else {
                if (debug) {
                    Logger.w("Failed to load configuration: ${configResult.exceptionOrNull()?.message}")
                }
                // Continue with default values
            }


        sdkConfig = SDKConfig(
            eventType = eventType,
            environment = environment,
            debug = debug,
            autoRetryOnError = autoRetryOnError,
            maxRetryAttempts = maxRetryAttempts,
            retryBackoffMultiplier = retryBackoffMultiplier,
            locales = locales,
            configLiveVideoId = configLiveVideoId,
            configLiveVideoOrientation = configLiveVideoOrientation,
            configLiveMediaTitle = configLiveMediaTitle,
            configLiveMediaSubTitle = configLiveMediaSubTitle,
            configState = configState,
            configMediaType = configMediaType,
            configMediaUrl = configMediaUrl,
            configMediaTitle = configMediaTitle,
            configMediaSubTitle = configMediaSubTitle,
            configMediaLoop = configMediaLoop,
            configIntervals = configIntervals
        )
        
        analyticsManager = AnalyticsManager(appContext, debug)
        
        // Create a standalone EventEmitter for Catalog operations
        // This is needed because BrightcoveExoPlayerVideoView doesn't expose eventEmitter property
        // EventEmitter is an interface, so we need to find the implementation class
        try {
            // Try to find and instantiate the EventEmitter implementation class
            val eventEmitterClass = try {
                Class.forName("com.brightcove.player.event.EventEmitterImpl")
            } catch (e: ClassNotFoundException) {
                try {
                    Class.forName("com.brightcove.player.event.DefaultEventEmitter")
                } catch (e2: ClassNotFoundException) {
                    null
                }
            }
            
            if (eventEmitterClass != null) {
                val constructor = eventEmitterClass.getDeclaredConstructor()
                constructor.isAccessible = true
                standaloneEventEmitter = constructor.newInstance() as EventEmitter
                if (debug) {
                    Logger.d("Standalone EventEmitter created successfully using ${eventEmitterClass.simpleName}")
                }
            } else {
                if (debug) {
                    Logger.w("Could not find EventEmitter implementation class - will try to get from player view when available")
                }
            }
        } catch (e: Exception) {
            if (debug) {
                Logger.e("Failed to create standalone EventEmitter: ${e.message}", e)
            }
        }
        
        isInitialized = true

        // Start periodic config updates
        startPeriodicConfigUpdates(context, debug)
    }

    /**
     * Update the SDK configuration with new values from API.
     * This is called when configuration changes dynamically.
     */
    internal fun updateSdkConfiguration(newConfigData: StreamConfigData) {
        // Recreate SDK config with updated values
        val currentConfig = sdkConfig
        if (currentConfig != null) {
            sdkConfig = SDKConfig(
                eventType = currentConfig.eventType,
                environment = currentConfig.environment,
                debug = currentConfig.debug,
                autoRetryOnError = currentConfig.autoRetryOnError,
                maxRetryAttempts = currentConfig.maxRetryAttempts,
                retryBackoffMultiplier = currentConfig.retryBackoffMultiplier,
                locales = currentConfig.locales,
                configLiveVideoId = newConfigData.liveVideoId,
                configLiveVideoOrientation = newConfigData.liveVideoOrientation,
                configLiveMediaTitle = newConfigData.liveMediaTitle,
                configLiveMediaSubTitle = newConfigData.liveMediaSubTitle,
                configState = newConfigData.state,
                configMediaType = newConfigData.mediaType,
                configMediaUrl = newConfigData.mediaUrl,
                configMediaTitle = newConfigData.mediaTitle,
                configMediaSubTitle = newConfigData.mediaSubTitle,
                configMediaLoop = newConfigData.mediaLoop,
                configIntervals = newConfigData.intervals
            )

            if (currentConfig.debug) {
                Logger.d("SDK configuration updated with new values")
            }
        }
    }
    
    /**
     * Get the SDK configuration.
     * @throws IllegalStateException if SDK is not initialized
     */
    internal fun getConfig(): SDKConfig {
        return sdkConfig ?: throw IllegalStateException(
            "BrightcoveLiveStreamSDK is not initialized. Call initialize() first."
        )
    }
    
    /**
     * Get the analytics manager.
     */
    internal fun getAnalyticsManager(): AnalyticsManager? {
        return analyticsManager
    }
    
    /**
     * Check if SDK is initialized.
     */
    @JvmStatic
    fun isInitialized(): Boolean = isInitialized

    /**
     * Returns the current time in milliseconds since January 1, 1970 UTC.
     * 
     * @return Current time in milliseconds as a Long
     */
    @JvmStatic
    fun currenttimemillis(): Long {
        return System.currentTimeMillis()
    }

    /**
     * Stop periodic configuration updates.
     * Useful when app is going to background or for cleanup.
     */
    @JvmStatic
    fun stopPeriodicUpdates() {
        stopPeriodicConfigUpdates()
    }

    /**
     * Manually trigger a configuration update from API.
     * @param debug Enable debug logging for this update
     */
    @JvmStatic
    fun updateConfigurationNow(debug: Boolean = false) {
        if (isInitialized) {
            updateConfigurationFromApi(debug)
        }
    }

    /**
     * Register a listener to be notified when configuration changes.
     * @param listener The listener to register
     */
    @JvmStatic
    fun addConfigurationChangeListener(listener: ConfigurationChangeListener) {
        if (!configChangeListeners.contains(listener)) {
            configChangeListeners.add(listener)
        }
    }

    /**
     * Unregister a configuration change listener.
     * @param listener The listener to remove
     */
    @JvmStatic
    fun removeConfigurationChangeListener(listener: ConfigurationChangeListener) {
        configChangeListeners.remove(listener)
    }

    /**
     * Remove all configuration change listeners.
     */
    @JvmStatic
    fun clearConfigurationChangeListeners() {
        configChangeListeners.clear()
    }
    
    /**
     * Get the standalone EventEmitter instance.
     * This can be used to set on player views to initialize MediaPlayback.
     */
    internal fun getStandaloneEventEmitter(): EventEmitter? = standaloneEventEmitter
    
    /**
     * Resolve credentials based on event type/environment with optional overrides.
     */
    
    /**
     * Create a Brightcove Catalog instance for video retrieval using the player view's EventEmitter.
     * 
     * @param brightcoveVideoView BrightcoveExoPlayerVideoView instance (can be null)
     * @return Catalog instance or null if player view is not available
     */
    internal fun getBrightcoveEmitter(
        brightcoveVideoView: BrightcoveExoPlayerVideoView?
    ): Catalog? {
        val config = getConfig()
        val accountId = config.getBrightcoveAccountId()
        val policyKey = config.getBrightcovePolicyKey()

        
        // Try to get EventEmitter from player view first (if available)
        var eventEmitter: EventEmitter? = null
        try {
            eventEmitter = brightcoveVideoView?.eventEmitter
        } catch (e: Exception) {
            if (config.debug) {
                Logger.d("Could not access EventEmitter from player view: ${e.message}")
            }
        }
        
        // If not available from player view, use standalone EventEmitter
        if (eventEmitter == null) {
            eventEmitter = standaloneEventEmitter
            if (config.debug && eventEmitter != null) {
                Logger.d("Using standalone EventEmitter for Catalog creation")
            }
        }
        
        if (eventEmitter == null) {
            if (config.debug) {
                Logger.e("No EventEmitter available - neither from player view nor standalone")
            }
            return null
        }
        
//        val baseUrl = Catalog.DEFAULT_EPA_BASE_URL //auth
//        val baseUrl = "https://license.live.brightcove.com/lic/aes" //auth
        val baseUrl = Catalog.DEFAULT_EDGE_BASE_URL //api

        if (config.debug) {
            Logger.d("=== Brightcove Catalog Configuration ===")
            Logger.d("Base URL: $baseUrl")
            Logger.d("Account ID: $accountId")
            Logger.d("Policy Key: $policyKey")
            Logger.d("Full API Endpoint Pattern: $baseUrl/accounts/$accountId/videos/{videoId}")
        }

        Logger.d("Brightcove Catalog Base URL: $baseUrl")
        Logger.d("Brightcove Account ID: $accountId")

        return try {
            val catalog = Catalog.Builder(eventEmitter, accountId)
//                .setBaseURL(baseUrl)
                .setPolicy(policyKey)
                .build()
            
            // Try to get the actual base URL from Catalog instance using reflection
            val actualBaseUrl = try {
                val baseUrlField = catalog.javaClass.getDeclaredField("baseURL")
                baseUrlField.isAccessible = true
                baseUrlField.get(catalog) as? String ?: baseUrl
            } catch (e: Exception) {
                // If reflection fails, use the constant value
                baseUrl
            }
            
            if (config.debug) {
                Logger.d("Actual Catalog Base URL: $actualBaseUrl")
                Logger.d("Catalog instance created successfully")
            }
            
            // Set up EventEmitter listeners to capture API calls if debug is enabled
            if (config.debug && eventEmitter != null) {
                setupBrightcoveApiLogging(eventEmitter, actualBaseUrl, accountId)
            }
            
            catalog
        } catch (e: Exception) {
            Logger.e("=== Brightcove Catalog Creation Error ===")
            Logger.e("Error Type: ${e.javaClass.simpleName}")
            Logger.e("Error Message: ${e.message ?: "Unknown error"}")
            Logger.e("Account ID: $accountId")
            Logger.e("Policy Key: ${if (policyKey.length > 20) policyKey.substring(0, 20) + "..." else policyKey}")
            Logger.e("Base URL: $baseUrl")
            Logger.e("EventEmitter Available: ${eventEmitter != null}")
            Logger.e("Stack Trace:")
            e.printStackTrace()
            Logger.e("=========================================")
            null
        }
    }

    /**
     * Set up EventEmitter listeners to log Brightcove API calls and network requests.
     */
    private fun setupBrightcoveApiLogging(eventEmitter: EventEmitter, baseUrl: String, accountId: String) {
        try {
            // Listen for catalog events that might contain API call information
            val eventTypes = listOf(
                "catalogRequest",
                "catalogResponse", 
                "error",
                "networkRequest",
                "networkResponse"
            )
            
            eventTypes.forEach { eventType ->
                try {
                    eventEmitter.on(eventType) { event ->
                        if (eventType == "error") {
                            Logger.e("=== Brightcove API Event: $eventType ===")
                        } else {
                            Logger.d("=== Brightcove API Event: $eventType ===")
                        }
                        
                        // Log all event properties
                        Logger.d("Event Type: $eventType")
                        Logger.d("Event Properties Count: ${event.properties.size}")
                        
                        event.properties.forEach { (key, value) ->
                            val valueStr = when {
                                value is String && value.length > 200 -> value.substring(0, 200) + "..."
                                else -> value.toString()
                            }
                            if (eventType == "error") {
                                Logger.e("  $key: $valueStr")
                            } else {
                                Logger.d("  $key: $valueStr")
                            }
                        }
                        
                        // Specific property logging
                        if (event.properties.containsKey("url")) {
                            Logger.d("API URL: ${event.properties["url"]}")
                        }
                        if (event.properties.containsKey("requestUrl")) {
                            Logger.d("Request URL: ${event.properties["requestUrl"]}")
                        }
                        if (event.properties.containsKey("responseCode")) {
                            val responseCode = event.properties["responseCode"]
                            if (responseCode != null && responseCode.toString().toIntOrNull() != null) {
                                val code = responseCode.toString().toInt()
                                if (code >= 400) {
                                    Logger.e("HTTP Response Code: $code (ERROR)")
                                } else {
                                    Logger.d("HTTP Response Code: $code (SUCCESS)")
                                }
                            }
                        }
                        if (event.properties.containsKey("error")) {
                            Logger.e("Error Details: ${event.properties["error"]}")
                        }
                        if (event.properties.containsKey("errorMessage")) {
                            Logger.e("Error Message: ${event.properties["errorMessage"]}")
                        }
                        if (event.properties.containsKey("errorCode")) {
                            Logger.e("Error Code: ${event.properties["errorCode"]}")
                        }
                        
                        if (eventType == "error") {
                            Logger.e("====================================")
                        } else {
                            Logger.d("====================================")
                        }
                    }
                } catch (e: Exception) {
                    // Some event types might not be available, ignore
                    Logger.w("Could not register listener for event type '$eventType': ${e.message}")
                }
            }
            
            Logger.d("Brightcove API logging listeners registered")
        } catch (e: Exception) {
            Logger.w("Failed to set up Brightcove API logging: ${e.message}")
        }
    }

    /**
     * Start periodic configuration updates from API.
     * Checks for config updates using the current effective polling interval.
     * This means config updates happen at the same frequency as stream polling.
     */
    private fun startPeriodicConfigUpdates(context: Context, debug: Boolean) {
        if (isPeriodicUpdatesEnabled) return

        configUpdateHandler = Handler(Looper.getMainLooper())
        configUpdateRunnable = object : Runnable {
            override fun run() {
                updateConfigurationFromApi(debug)
                // Schedule next update using current effective polling interval
                val nextInterval = sdkConfig?.getEffectivePollingInterval() ?: (1 * 60 * 1000L) // fallback to 1 minutes
                configUpdateHandler?.postDelayed(this, nextInterval)
            }
        }

        isPeriodicUpdatesEnabled = true
        // Start the first update using current effective polling interval
        val initialInterval = sdkConfig?.getEffectivePollingInterval() ?: (1 * 60 * 1000L) // fallback to 1 minutes
        configUpdateHandler?.postDelayed(configUpdateRunnable!!, initialInterval)

        if (debug) {
            val intervalMinutes = initialInterval / 1000 / 60
            Logger.d("Started periodic configuration updates (every $intervalMinutes minutes based on current polling interval)")
        }
    }

    /**
     * Stop periodic configuration updates.
     */
    private fun stopPeriodicConfigUpdates() {
        configUpdateHandler?.removeCallbacks(configUpdateRunnable!!)
        configUpdateHandler = null
        configUpdateRunnable = null
        isPeriodicUpdatesEnabled = false
    }

    /**
     * Update configuration from API if changes are detected.
     */
    private fun updateConfigurationFromApi(debug: Boolean) {
        try {
            val configManager = ConfigurationManager.Companion.getInstance()
//            val apiUrl = "https://squirrel-prepared-marlin.ngrok-free.app/stream_config.json"
            val apiUrl = "https://stg-spz.sportz.io/static-assets/feeds/config.json?v="+currenttimemillis()

            // Store current config state before attempting update
            val currentConfigResult = if (configManager.isConfigurationLoaded()) {
                configManager.getConfiguration(
                    sdkConfig?.eventType ?: SdkEventType.mobile,
                    sdkConfig?.environment ?: Environment.prod,
                    sdkConfig?.locales ?: "en",
                    debug
                )
            } else null

            val configResult = configManager.loadConfigurationFromApi(apiUrl, debug)
            if (configResult.isSuccess) {
                // Check if configuration has actually changed by comparing with previous state
                if (currentConfigResult?.isSuccess == true) {
                    val newData = configManager.getConfiguration(
                        sdkConfig?.eventType ?: SdkEventType.mobile,
                        sdkConfig?.environment ?: Environment.prod,
                        sdkConfig?.locales ?: "en",
                        debug
                    ).getOrThrow()

                    onConfigurationUpdated(newData)
//                        // Notify listeners or update UI if needed
                } else {
                    // First time loading config
                    val newData = configManager.getConfiguration(
                        sdkConfig?.eventType ?: SdkEventType.mobile,
                        sdkConfig?.environment ?: Environment.prod,
                        sdkConfig?.locales ?: "en",
                        debug
                    ).getOrThrow()

                    if (debug) {
                        Logger.d("Configuration loaded from API for first time: liveVideoId=${newData.liveVideoId}, state=${newData.state}")
                    }
                    onConfigurationUpdated(newData)
                }
            } else {
                if (debug) {
                    Logger.d("Periodic config update failed: ${configResult.exceptionOrNull()?.message}")
                }
            }
        } catch (e: Exception) {
            if (debug) {
                Logger.e("Error during periodic config update: ${e.message}")
            }
        }
    }


    /**
     * Called when configuration is updated from API.
     * Notifies all registered listeners of the configuration change.
     */
    internal fun onConfigurationUpdated(newConfig: StreamConfigData) {
        if (sdkConfig?.debug == true) {
            Logger.d("Configuration updated: liveVideoId=${newConfig.liveVideoId}, state=${newConfig.state}")
        }

        // Update the SDK configuration with new values
        updateSdkConfiguration(newConfig)

        // Notify all registered listeners
        configChangeListeners.forEach { listener ->
            try {
                listener.onConfigurationChanged(newConfig)
            } catch (e: Exception) {
                if (sdkConfig?.debug == true) {
                    Logger.e("Error notifying configuration listener: ${e.message}")
                }
            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
fun base64Url(bytes: ByteArray): String =
    Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)

/**
 * Load a private key from a PEM file.
 * Supports both PKCS#8 format (-----BEGIN PRIVATE KEY-----) and PKCS#1 format (-----BEGIN RSA PRIVATE KEY-----).
 * 
 * @param pemFilePath Path to the PEM file (can be absolute path or relative to assets)
 * @param context Application context (optional, used for loading from assets if file path doesn't exist)
 * @return PrivateKey instance
 * @throws Exception if the file cannot be read or the key cannot be parsed
 */
@RequiresApi(Build.VERSION_CODES.O)
fun loadPrivateKeyFromPem(pemFilePath: String, context: Context? = null): PrivateKey {
    val pemContent = try {
        // Try to load from file system first
        val file = File(pemFilePath)
        Logger.d("Attempting to load private key from file system: $pemFilePath")
        if (file.exists() && file.canRead()) {
            Logger.d("File exists and is readable, loading content...")
            val content = file.readText()
            Logger.d("File content loaded successfully (${content.length} characters)")
            content
        } else {
            Logger.d("File not found or not readable, trying assets folder...")
            // Try to load from assets if context is provided
            if (context == null) {
                throw IllegalArgumentException("Context is null, cannot load from assets. File path: $pemFilePath")
            }
            try {
                val content = context.assets.open(pemFilePath).bufferedReader().use { it.readText() }
                Logger.d("Private key loaded from assets successfully (${content.length} characters)")
                content
            } catch (assetsError: FileNotFoundException) {
                Logger.e("Private key file not found in assets: $pemFilePath")
                Logger.e("File system path checked: ${file.absolutePath}")
                Logger.e("File exists: ${file.exists()}")
                Logger.e("File can read: ${file.canRead()}")
                throw IllegalArgumentException("Private key file not found in assets or file system: $pemFilePath", assetsError)
            } catch (assetsError: Exception) {
                Logger.e("Error loading from assets: ${assetsError.javaClass.simpleName} - ${assetsError.message}")
                throw IllegalArgumentException("Failed to load private key from assets: $pemFilePath", assetsError)
            }
        }
    } catch (e: IllegalArgumentException) {
        // Re-throw IllegalArgumentException as-is (already has good error message)
        throw e
    } catch (e: Exception) {
        Logger.e("Unexpected error loading private key: ${e.javaClass.simpleName} - ${e.message}")
        throw IllegalArgumentException("Failed to load private key from: $pemFilePath", e)
    }
    
    return parsePemPrivateKey(pemContent)
}

/**
 * Parse a PEM-formatted private key string into a PrivateKey object.
 * Supports both PKCS#8 and PKCS#1 formats.
 */
@RequiresApi(Build.VERSION_CODES.O)
fun parsePemPrivateKey(pemContent: String): PrivateKey {
    try {
        Logger.d("Parsing PEM private key content (${pemContent.length} characters)")
        
        // Check if content is empty
        if (pemContent.isBlank()) {
            throw IllegalArgumentException("PEM content is empty or blank")
        }
        
        // Remove PEM headers and whitespace
        val privateKeyPEM = pemContent
            .replace("-----BEGIN PRIVATE KEY-----", "")
            .replace("-----END PRIVATE KEY-----", "")
            .replace("-----BEGIN RSA PRIVATE KEY-----", "")
            .replace("-----END RSA PRIVATE KEY-----", "")
            .replace("\\s".toRegex(), "")
        
        if (privateKeyPEM.isBlank()) {
            throw IllegalArgumentException("PEM content after removing headers is empty. Check if file contains valid PEM format.")
        }
        
        Logger.d("PEM headers removed, base64 content length: ${privateKeyPEM.length}")
        
        // Decode base64
        val keyBytes = try {
            Base64.getDecoder().decode(privateKeyPEM)
        } catch (e: IllegalArgumentException) {
            Logger.e("Failed to decode base64 content. Content preview: ${privateKeyPEM.take(50)}...")
            throw IllegalArgumentException("Invalid base64 encoding in PEM file", e)
        }
        
        Logger.d("Base64 decoded successfully, key bytes length: ${keyBytes.size}")
        
        // Try PKCS#8 format first (most common)
        try {
            Logger.d("Attempting PKCS#8 format parsing...")
            val keySpec = PKCS8EncodedKeySpec(keyBytes)
            val keyFactory = KeyFactory.getInstance("RSA")
            val privateKey = keyFactory.generatePrivate(keySpec)
            Logger.d("Successfully parsed as PKCS#8 format")
            return privateKey
        } catch (e: Exception) {
            Logger.d("PKCS#8 parsing failed: ${e.javaClass.simpleName} - ${e.message}, trying PKCS#1 format...")
            // If PKCS#8 fails, try PKCS#1 format
            // PKCS#1 keys need to be wrapped in PKCS#8 structure
            try {
                val pkcs1Length = keyBytes.size
                val totalLength = pkcs1Length + 22
                val pkcs8Header = byteArrayOf(
                    0x30.toByte(), 0x82.toByte(), ((totalLength shr 8) and 0xff).toByte(), (totalLength and 0xff).toByte(), // SEQUENCE
                    0x02.toByte(), 0x01.toByte(), 0x00.toByte(), // INTEGER 0 (version)
                    0x30.toByte(), 0x0D.toByte(), // SEQUENCE (algorithm)
                    0x06.toByte(), 0x09.toByte(), 0x2A.toByte(), 0x86.toByte(), 0x48.toByte(), 0x86.toByte(), 0xF7.toByte(), 0x0D.toByte(), 0x01.toByte(), 0x01.toByte(), 0x01.toByte(), // OID: RSA
                    0x05.toByte(), 0x00.toByte(), // NULL
                    0x04.toByte(), 0x82.toByte(), ((pkcs1Length shr 8) and 0xff).toByte(), (pkcs1Length and 0xff).toByte() // OCTET STRING
                )
                val pkcs8Bytes = pkcs8Header + keyBytes
                val keySpec = PKCS8EncodedKeySpec(pkcs8Bytes)
                val keyFactory = KeyFactory.getInstance("RSA")
                val privateKey = keyFactory.generatePrivate(keySpec)
                Logger.d("Successfully parsed as PKCS#1 format (converted to PKCS#8)")
                return privateKey
            } catch (pkcs1Error: Exception) {
                Logger.e("PKCS#1 parsing also failed: ${pkcs1Error.javaClass.simpleName} - ${pkcs1Error.message}")
                throw IllegalArgumentException("Failed to parse PEM private key in both PKCS#8 and PKCS#1 formats. Original error: ${e.message}", pkcs1Error)
            }
        }
    } catch (e: IllegalArgumentException) {
        // Re-throw IllegalArgumentException as-is
        throw e
    } catch (e: Exception) {
        Logger.e("Unexpected error parsing PEM: ${e.javaClass.simpleName} - ${e.message}")
        throw IllegalArgumentException("Failed to parse PEM private key: ${e.message}", e)
    }
}

@RequiresApi(Build.VERSION_CODES.O)
fun generateBrightcoveJWT(privateKey: PrivateKey, accountId: String): String {
    val now = System.currentTimeMillis() / 1000

    val header = JSONObject()
        .put("type", "JWT")
        .put("alg", "RS256")

    val payload = JSONObject()
        .put("accid", accountId)
        .put("iat", now)
        .put("exp", now + 3600)

    val headerB64 = base64Url(header.toString().toByteArray())
    val payloadB64 = base64Url(payload.toString().toByteArray())

    val signingInput = "$headerB64.$payloadB64"

    val signature = Signature.getInstance("SHA256withRSA")
    signature.initSign(privateKey)
    signature.update(signingInput.toByteArray())

    val signed = signature.sign()
    val signatureB64 = base64Url(signed)

    return "$signingInput.$signatureB64"
}

