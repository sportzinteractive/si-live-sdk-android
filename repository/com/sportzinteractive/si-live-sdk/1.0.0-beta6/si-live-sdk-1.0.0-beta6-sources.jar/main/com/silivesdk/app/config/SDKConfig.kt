package com.silivesdk.app.config

import com.silivesdk.app.model.Environment
import com.silivesdk.app.model.EventType
import com.silivesdk.app.model.MediaType

/**
 * Internal SDK configuration data class.
 */
internal data class SDKConfig(
    val eventType: EventType,
    val environment: Environment,
    val debug: Boolean = false,
    val autoRetryOnError: Boolean = true,
    val maxRetryAttempts: Int = 3,
    val retryBackoffMultiplier: Double = 2.0,
    // New configuration parameters
    val locales: String = "en",
    val configLiveVideoId: String = "",
    val configLiveVideoOrientation: String = "portrait",
    val configLiveMediaTitle: String = "",
    val configLiveMediaSubTitle: String = "",
    val configState: String = "",
    val configMediaType: MediaType = MediaType.IMAGE,
    val configMediaUrl: String = "",
    val configMediaTitle: String = "",
    val configMediaSubTitle: String = "",
    val configMediaLoop: Boolean,
    val configIntervals: Map<String, Int> = emptyMap() // polling intervals in seconds
) {
    // Hardcoded credentials
//    private val hardcodedAccountId = "6415818918001"
//    private val hardcodedPolicyKey = "BCpkADawqM3ikTFBoFaNzjghiJjf1GzxYQ0kOqZTl_VBJfjxqdil2A0wfqN_tDj8CSJNwPPsz9EQX8unZYHCkXq6nq5THsJ9ShpPuWoKaCCTuymjtweUk4DWqbdBNgF5ZOeG1DDeoaMQzJIoVa92V09iU5ET5R2meoG3FQ"
    private val hardcodedAccountId = "6416100787001"
    private val hardcodedPolicyKey = "BCpkADawqM3Yy8QOkM36aomF79OIvlL585FAiB2MQK38PqrCnTPbFPjo8eQX7Qz1qhT9N7d4HHwApHPopKAq-fhxagmaAbSL2rZJ_eUxle5Z4Kmfp4Yig_RIa4NGcEpdTX2DJ_EqnV9hyxSVJJkdq8NEbtvxUy3LXVEP-Q"
//    private val hardcodedPolicyKey = ""
    /**
     * Get Brightcove Account ID (hardcoded value).
     */
    fun getBrightcoveAccountId(): String = hardcodedAccountId

    /**
     * Get Brightcove Policy Key (hardcoded value).
     */
    fun getBrightcovePolicyKey(): String = hardcodedPolicyKey

    /**
     * Get the effective live video ID (from config if available, otherwise empty).
     */
    fun getEffectiveVideoId(): String = configLiveVideoId.ifBlank { "" }

    /**
     * Get the effective polling interval based on config state and useConfig flag.
     */
    fun getEffectivePollingInterval(): Long {
        return if (configIntervals.isNotEmpty()) {
            // Use intervals from config (convert seconds to milliseconds)
            val intervalSeconds = when (configState.lowercase()) {
                "prelive" -> configIntervals["preLive"] ?: configIntervals["postLive"]
                "postlive" -> configIntervals["postLive"] ?: configIntervals["preLive"]
                "live" -> configIntervals["live"]
                else -> null
            }
            intervalSeconds?.let { it * 1000L } ?: 30_000L // 30 seconds fallback
        } else {
            30_000L // 30 seconds default
        }
    }
}

